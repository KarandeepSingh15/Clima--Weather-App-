package co.appbrewery.clima;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {

}
